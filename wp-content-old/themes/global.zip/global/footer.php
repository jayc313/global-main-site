<?php

/**
 * The template for displaying the footer
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 */

?>

<footer id="site-footer" class=" pv-1" style="color: #fff; background-color: #707070;">
    <div class="container">
        <div class="row">
   

            <div class="col-12 tac">
                <p style="margin-bottom: 0px;">Copyright © 2023 Global Brand Communications. All rights reserved. Cookies & Privacy Policy. | Terms of Use</p>
            
            </div>

            

    
      

    
            </div>


        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>

</html>