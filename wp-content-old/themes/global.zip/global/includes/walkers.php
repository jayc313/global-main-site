<?php
class Filter_Nav_Walker extends Walker_Nav_Menu
{
    public function start_el(&$output, $item, $depth = 0, $args = [], $id = 0)
    {
        $indent = $depth ? str_repeat("\t", $depth) : "";
        $classes = empty($item->classes) ? [] : (array) $item->classes;

        $class_names = join(
            " ",
            apply_filters(
                "nav_menu_css_class",
                array_filter($classes),
                $item,
                $args,
                $depth
            )
        );
        
        $class_names = $class_names
            ? ' class="' . esc_attr($class_names) . '"'
            : "";

        $id = apply_filters(
            "nav_menu_item_id",
            "menu-item-" . $item->ID,
            $item,
            $args,
            $depth
        );

        $id = $id ? ' id="' . esc_attr($id) . '"' : "";
        $output .= $indent . "<li" . $id . $class_names . ">";
        $atts = [];
        $atts["title"] = !empty($item->attr_title) ? $item->attr_title : "";
        $atts["target"] = !empty($item->target) ? $item->target : "";
        $atts["rel"] = !empty($item->xfn) ? $item->xfn : "";
        $page_name = apply_filters("the_title", $item->title, $item->ID);
        $atts = apply_filters(
            "nav_menu_link_attributes",
            $atts,
            $item,
            $args,
            $depth
        );

        $attributes = "";
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = "href" === $attr ? esc_url($value) : esc_attr($value);
                $attributes .= " " . $attr . '="' . $value . '"';
            }
        }

        $item_output = $args->before;
        $item_output .= "<a" . $attributes . ">";
        /** This filter is documented in wp-includes/post-template.php */

        $item_output .= "</a>";
        $item_output .= $args->after;
        $output .= apply_filters(
            "walker_nav_menu_start_el",
            $item_output,
            $item,
            $depth,
            $args
        );
    }
    public function end_el(&$output, $item, $depth = 0, $args = [])
    {
        $output .= "</li>\n";
    }
}
