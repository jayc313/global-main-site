<?php

$contentDefault = $gbcCF->create_component('Content Default',[
    'Content'    => [ 'type' => 'rich_text' ],
    'Text Alignment Mobile' => ['type'  => 'text_align', 'set_width' => '33.333',],
    'Text Alignment Tablet' => ['type'  => 'text_align', 'set_width' => '33.333',],
    'Text Alignment Desktop' => ['type'  => 'text_align', 'set_width' => '33.333',],
   

]);
