<div class="container content">
    <div class="row">
        <div class="col-12">
            <?php echo apply_filters('the_content', $args['content']); ?>
        </div>
    </div>
</div>