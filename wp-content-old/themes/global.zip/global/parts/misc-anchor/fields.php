<?php

$gbcCF->create_component('Misc Anchor', [
    'Anchor Name' => [
        'type' => 'text'
    ],
]);
