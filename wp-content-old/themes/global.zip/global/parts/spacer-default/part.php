
<!-- Spacer -->
<div class="mt-<?php echo $args['spacer-height-mobile']; ?> mt-lg-<?php echo $args['spacer-height-tablet']; ?> mt-xl-<?php echo $args['spacer-height-desktop']; ?>"></div>